package DB;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Login")
public class Login extends HttpServlet 
{
	final static String url="jdbc:mysql://localhost/DSC";
	final static String user="root";
	final static String pwd="";
	
	static Connection getConnection() throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con =DriverManager.getConnection(url,user,pwd);
		return con;
	}
	
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int application_id=Integer.parseInt(request.getParameter("application_id"));
		String password=request.getParameter("password");
		try
		{
			Connection con=getConnection();
			String query="select * from user_login where application_id="+application_id+" and password='"+password+"'";
			Statement st=con.createStatement();
			
			ResultSet rs=st.executeQuery(query);
			if(!rs.next())
			{
				String path="login.jsp";
				RequestDispatcher rd=request.getRequestDispatcher(path);
				rd.forward(request, response);
			}
			else
			{
				System.out.println("Success Login"+rs.getInt("application_id")+"==="+rs.getString("password"));
				int app_id=rs.getInt("application_id");
				String pass=rs.getString("password");
				String query1="select mobile,email from user_info where application_id="+app_id+"";
				ResultSet rs1=st.executeQuery(query1);
				while(rs1.next())
				{
					String mob=rs1.getString("mobile");
					String email=rs1.getString("email");
					
					System.out.println("in login "+mob);
					
					request.setAttribute("mobile",mob);
					request.setAttribute("email",email);
					request.setAttribute("application_id", app_id);
					request.setAttribute("password", pass);
					
					HttpSession session=request.getSession();
					session.setAttribute("Application_Id", app_id);
					//String path="logininden.jsp";
					RequestDispatcher rd=request.getRequestDispatcher("OtpServlet");
					rd.forward(request, response);
					
					
					
				}
				
				
		
			}

			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	} 
}