package DB;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Random;

/**
 * Servlet implementation class OtpServlet
 */
@WebServlet("/OtpServlet")
public class OtpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public OtpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String mobno=(String) request.getAttribute("mobile");
		String emailid= (String) request.getAttribute("email");
		int app_id=(int) request.getAttribute("application_id");
		String pass=(String) request.getAttribute("password");
		
	    Random r=new Random();
        int otp = r.nextInt(1000000); // no. of zeros depends on the OTP digit
      //System.out.println(otp); // for console 

        HttpSession session=request.getSession();
        session.setAttribute("otp", otp);
        //Your authentication key
        String authkey = "296684A1eYIn1BUnV5d92fe72";
        
        //System.out.println(mobno);
        //Multiple mobiles numbers separated by comma
        String mobile = "91"+mobno;
      //  System.out.println("after"+mobile);
        
        //Sender ID,While using route4 sender id should be 6 characters long.
        String sender = "DSCKYC"; 
        
        String message = "Your OTP Code is:"+otp+"";
        
        String email = emailid;
       
       // String template = "1117";
       
        String otp_expiry = "10";
        //define route
        //String route="default";

        //Prepare Url
        URLConnection myURLConnection=null;
        URL myURL=null;
        BufferedReader reader=null;

        //encoding message
      //  String encoded_message=URLEncoder.encode(message);

        //Send SMS API
        String mainUrl="https://control.msg91.com/api/sendotp.php?email=";

        //Prepare parameter string
	
	  StringBuilder sbPostData= new StringBuilder(mainUrl);
	  sbPostData.append("&email="+email); 
	 // sbPostData.append("&template="+template);
	  sbPostData.append("&otp="+otp); 
	  sbPostData.append("&otp_expiry="+otp_expiry);
	  sbPostData.append("&sender="+sender); 
	  sbPostData.append("&message="+message);
	  
	  sbPostData.append("&mobile="+mobile);
	  sbPostData.append("&authkey="+authkey+"");
	 
        //final string
       mainUrl = sbPostData.toString();
        try
        {
            //prepare connection
            myURL = new URL(mainUrl);
            myURLConnection = myURL.openConnection();
            myURLConnection.connect();
            reader= new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));
            //reading response
            String responsestatus;
            while ((responsestatus = reader.readLine()) != null)
            //print response
            System.out.println(responsestatus.toString());

            //finally close connection
            reader.close();
            
            String path="OTPLogin.jsp";
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
            
        }
        catch (IOException e)
        {
                e.printStackTrace();
        }
    }

		
		
	}


