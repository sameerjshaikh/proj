package DB;
import java.util.*;

public class randomequetion 
{
	public static void main(String[] args)
	{
	String[] questionAr=new String[5];
	questionAr[0]="Question No 1";
	questionAr[1]="Question No 2";
	questionAr[2]="Question No 3";
	questionAr[3]="Question No 4";
	questionAr[4]="Question No 5";
	Random generator = new Random();
	int r = generator.nextInt(questionAr.length);
	System.out.println(questionAr[r]);
	}
}
