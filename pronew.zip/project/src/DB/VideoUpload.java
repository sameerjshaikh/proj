package DB;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.omg.CORBA.Request;

@WebServlet("/newupload")
public class VideoUpload extends HttpServlet {
	 private final String UPLOAD_DIRECTORY = "C:/uploads";
	 String path=null;
	 
	 final static String url="jdbc:mysql://localhost/DSC";
		final static String user="root";
		final static String pwd="";
		
		static Connection getConnection() throws Exception
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection(url,user,pwd);
			System.out.println("in connnn");
			return con;
		}
		
	
	 

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Random r=new Random();
        int id = r.nextInt(10000000);
		System.out.println("in do post");
		if(ServletFileUpload.isMultipartContent(request)){
            try {
            	System.out.println("in try");
                List<FileItem> multiparts = new ServletFileUpload( new DiskFileItemFactory()).parseRequest(request);
                System.out.println("check"+multiparts);
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        String name = new File(item.getName()+id+".mp4").getName();
                        item.write( new File(UPLOAD_DIRECTORY + File.separator + name));
                       path= UPLOAD_DIRECTORY + File.separator + name;
                    }
                }
            
               //File uploaded successfully
              // request.setAttribute("message", "File Uploaded Successfully");
            } catch (Exception ex) {
             
            	//  request.setAttribute("message", "File Upload Failed due to " + ex);
            }          
          
        }else{
            request.setAttribute("message",
                                 "Sorry this Servlet only handles file upload request");
        }
		
		  HttpSession session=request.getSession(false);
		int app_id= (int) session.getAttribute("Application_Id");
		System.out.println("db_checkappid--"+app_id);
		
		  String query="insert into user_status(application_id,status) values(?,?)";
		  try {
			  
			  System.out.println("in jdbc try");
			  Connection con =getConnection();
			  PreparedStatement ps =con.prepareStatement(query); 
			  ps.setInt(1, app_id);
			  ps.setString(2, path);
			  int RowsAffected=ps.executeUpdate();
				if(RowsAffected!=1)
				{
				System.out.println("video not inserted");
				}
				else
				{
					System.out.println("video  inserted");
					
				}
			  
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 	
		
      //  request.getRequestDispatcher("result.jsp").forward(request, response);
      
    
	}
}
